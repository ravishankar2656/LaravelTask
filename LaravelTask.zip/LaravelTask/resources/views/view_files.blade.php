<!DOCTYPE html>
<html>
<head>
<title>Font Awesome Icons</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>


<table>
<tr><th>Image</th><th></th><th></th></tr>
@foreach($a as $ab)
<?php 
$dile = substr($ab, strrpos($ab, '.' )+1);
$path = public_path('images/');
?>
 @if(!empty($dile))
<tr><td>
@if($dile=='pdf')
<div width="100px" height="100px"><i class="fa fa-file-pdf-o" width="100px" height="100px">{{$ab}}</i><div>
@elseif($dile=='jpg' || $dile=='png' || $dile=='jpeg')
<img src="images/{{$ab}}" alt="image" ,width=100px, height=100px />
@else
<div width="100px" height="100px"><i class="fa fa-file" width="100px" height="100px">{{$ab}}</i><div>	
@endif
</td>
<td><a href="DeleteFile/{{$ab}}">Delete</a></td>
<td><a href="DownloadFile/{{$ab}}">Download</a></td>
</tr>
@endif
@endforeach
</table>
</body>
</html> 
