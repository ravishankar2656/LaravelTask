<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FileController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});
Route::post('saveUser', [FileController::class, 'SaveFile']);
Route::get('ViewFiles', [FileController::class, 'ViewFiles']);
Route::get('DownloadFile/{img_nm}', [FileController::class, 'DownloadFile']);
Route::get('DeleteFile/{img_nm}', [FileController::class, 'DeleteFile']);
