<!DOCTYPE html>
<html>
<head>
<title>Font Awesome Icons</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>


<table>
<tr><th>Image</th><th></th><th></th></tr>
<?php $__currentLoopData = $a; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php 
$dile = substr($ab, strrpos($ab, '.' )+1);
$path = public_path('images/');
?>
 <?php if(!empty($dile)): ?>
<tr><td>
<?php if($dile=='pdf'): ?>
<div width="100px" height="100px"><i class="fa fa-file-pdf-o" width="100px" height="100px"><?php echo e($ab); ?></i><div>
<?php elseif($dile=='jpg' || $dile=='png' || $dile=='jpeg'): ?>
<img src="images/<?php echo e($ab); ?>" alt="image" ,width=100px, height=100px />
<?php else: ?>
<div width="100px" height="100px"><i class="fa fa-file" width="100px" height="100px"><?php echo e($ab); ?></i><div>	
<?php endif; ?>
</td>
<td><a href="DeleteFile/<?php echo e($ab); ?>">Delete</a></td>
<td><a href="DownloadFile/<?php echo e($ab); ?>">Download</a></td>
</tr>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</html> 
<?php /**PATH C:\xampp\htdocs\LaravelTask\resources\views/view_files.blade.php ENDPATH**/ ?>