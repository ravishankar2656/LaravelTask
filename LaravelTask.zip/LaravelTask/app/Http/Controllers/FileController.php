<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;

class FileController extends Controller
{
   
    public function SaveFile(Request $request){
		if($request->hasFile('select_file'))
		{
			$images = $request->file('select_file');
			foreach($images as $image) {
			$new_name = rand() . '.' . $image->getClientOriginalExtension();
			$image->move(public_path('images'), $new_name);
			}
			$jsonAnswer = array('ret' => 'true','response' => 'true');
			echo json_encode($jsonAnswer);
			
		}else{
			
			echo 'Something went wrong';
		}
		
	}		
		 public function ViewFiles(Request $request){
			 
			 
			 $dir = "images/";
			$a = scandir($dir);			
			return view('view_files',compact('a'));

		} 
			 
		 public function DownloadFile(Request $request, $img_nm){
			 
			 $path = "http://localhost/LaravelTask/public/images/".$img_nm;

			Storage::disk('local')->put($img_nm, file_get_contents($path));
			$path = Storage::path($img_nm);
			return response()->download($path);
			
		 }
		 
		 public function DeleteFile(Request $request, $img_nm){
			 
			 $file_path = app_path("../public/images/".$img_nm); // app_path("public/test.txt");

			if(File::exists($file_path)){
				echo 'File deleted'; echo '<br>';
				echo '<a href="http://localhost/LaravelTask/public/ViewFiles"> Go Back</a>';
				File::delete($file_path);
				}else{
				
				echo 'File not exist';echo '<br>';
				echo '<a href="http://localhost/LaravelTask/public/ViewFiles"> Go Back</a>';
			}
	
			 
		 }
		
	
}
